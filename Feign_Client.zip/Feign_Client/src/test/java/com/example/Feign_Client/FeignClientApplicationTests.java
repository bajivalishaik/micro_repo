package com.example.Feign_Client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
