package com.example.product_FiegnClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductFiegnClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductFiegnClientApplication.class, args);
	}

}
