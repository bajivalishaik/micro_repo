package com.example.product_FiegnClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductFiegnClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
